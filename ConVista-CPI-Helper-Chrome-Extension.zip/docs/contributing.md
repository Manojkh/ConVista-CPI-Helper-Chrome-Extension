
# Contributing

Pull requests are welcome and I hope the community will take part with great ideas and support.

For major changes, please open an issue first to discuss what you would like to change.

This is the first Open Source project for me. If you have any input in regards to code quality, architecture and how to handle open source projects, you are welcome.

  

**Working on your first Pull Request?** You can learn how from this *free* series [How to Contribute to an Open Source Project on GitHub](https://egghead.io/series/how-to-contribute-to-an-open-source-project-on-github)